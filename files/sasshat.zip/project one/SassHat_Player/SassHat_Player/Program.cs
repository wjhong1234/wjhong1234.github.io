﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Media;

namespace SassHat_Player
{
    class Program
    {
        static void Main(string[] args)
        {
            SerialPort arduinoIn = new SerialPort();
            arduinoIn.BaudRate = 9600;
            arduinoIn.PortName = "COM4";
            arduinoIn.Open();

            while (true)
            {
                string step = arduinoIn.ReadLine();

                if (step.Trim().Equals("0"))
                {
                    //play hello track
                    SoundPlayer track0 = new SoundPlayer(@"C:\\Users\\William Hong\\Documents\\School Crap\\[CPSC 581] Human-Computer Interaction II\\project one\\assets\\audio\\0.wav");
                    Console.WriteLine("S0: Playing Track 0...");
                    track0.Load();
                    track0.Play();
                }
                else if (step.Trim().Equals("1"))
                {
                    //play introduction track
                    SoundPlayer track1 = new SoundPlayer(@"C:\\Users\\William Hong\\Documents\\School Crap\\[CPSC 581] Human-Computer Interaction II\\project one\\assets\\audio\\1.wav");
                    Console.WriteLine("S1: Playing Track 1...");
                    track1.Load();
                    track1.Play();
                }
                else if (step.Trim().Equals("2"))
                {
                    //play key sass track
                    SoundPlayer track2 = new SoundPlayer(@"C:\\Users\\William Hong\\Documents\\School Crap\\[CPSC 581] Human-Computer Interaction II\\project one\\assets\\audio\\2.wav");
                    Console.WriteLine("S2: Playing Track 2...");
                    track2.Load();
                    track2.Play();
                }
                else if (step.Trim().Equals("3"))
                {
                    //play keyy sass track 2
                    SoundPlayer track3 = new SoundPlayer(@"C:\\Users\\William Hong\\Documents\\School Crap\\[CPSC 581] Human-Computer Interaction II\\project one\\assets\\audio\\3.wav");
                    Console.WriteLine("S3: Playing Track 3...");
                    track3.Load();
                    track3.Play();
                }
                else if (step.Trim().Equals("4"))
                {
                    //play key sass track 3
                    SoundPlayer track4 = new SoundPlayer(@"C:\\Users\\William Hong\\Documents\\School Crap\\[CPSC 581] Human-Computer Interaction II\\project one\\assets\\audio\\4.wav");
                    Console.WriteLine("S4: Playing Track 4...");
                    track4.Load();
                    track4.Play();
                }
                else if (step.Trim().Equals("5"))
                {
                    //play task reminder track
                    SoundPlayer track5 = new SoundPlayer(@"C:\\Users\\William Hong\\Documents\\School Crap\\[CPSC 581] Human-Computer Interaction II\\project one\\assets\\audio\\5.wav");
                    Console.WriteLine("S5: Playing Track 5...");
                    track5.Load();
                    track5.Play();
                }
                else if (step.Trim().Equals("6"))
                {
                    //play adding presentation track
                    SoundPlayer track6 = new SoundPlayer(@"C:\\Users\\William Hong\\Documents\\School Crap\\[CPSC 581] Human-Computer Interaction II\\project one\\assets\\audio\\6.wav");
                    Console.WriteLine("S6: Playing Track 6...");
                    track6.Load();
                    track6.Play();
                }
                else if (step.Trim().Equals("7"))
                {
                    //play goodbye track
                    SoundPlayer track7 = new SoundPlayer(@"C:\\Users\\William Hong\\Documents\\School Crap\\[CPSC 581] Human-Computer Interaction II\\project one\\assets\\audio\\7.wav");
                    Console.WriteLine("S7: Playing Track 7...");
                    track7.Load();
                    track7.Play();
                }
            }
        }
    }
}
